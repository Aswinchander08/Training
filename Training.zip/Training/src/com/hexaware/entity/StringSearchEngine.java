package com.hexaware.entity;

import java.util.ArrayList;
import java.util.List;

public class StringSearchEngine {

    private String originalText;

    public StringSearchEngine(String originalText) {
        this.originalText = originalText;
    }

    public List<Integer> findoccurrences(String substring) {
        List<Integer> occurrences = new ArrayList<>();
        int index = originalText.indexOf(substring);
        while (index != -1) {
            occurrences.add(index);
            index = originalText.indexOf(substring, index + 1);
        }
        return occurrences;
    }



    public static void main(String[] args) {
        StringSearchEngine se = new StringSearchEngine("Hi my name is aswin chander . How are you ?. How is your mother and father , How is work ?");

        String substringToSearch = "how";
        List<Integer> occurrences = se.findoccurrences(substringToSearch);

        System.out.println("Occurrences of '" + substringToSearch + "': " + occurrences);

     
    }
}
