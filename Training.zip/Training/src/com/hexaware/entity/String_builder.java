package com.hexaware.entity;



public class String_builder {
	StringBuilder s;
    
	public String_builder(String word) {
		s=new StringBuilder(word);
	}
	public String_builder( ) {
		
	}
	public String_builder appends(String word)
	{
		s.append(word);
		return this;
	}
	public String_builder insert(int index, String str) {
        s.insert(index, str);
        return this;
    }
	public String_builder delete(int start, int end) {
        s.delete(start, end);
        return this;
    }

    public String toString() {
        return s.toString();
    }

	
	public static void main(String[] args) {
		String_builder word=new String_builder("Hi");
		word.insert(2, "beautiful");

        // Delete
        word.delete(0, 1);

        // Print the final result
        System.out.println(word.toString());
	}

}
