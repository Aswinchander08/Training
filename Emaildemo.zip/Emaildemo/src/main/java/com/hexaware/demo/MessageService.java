package com.hexaware.demo;

public interface MessageService {
	void sendMessage(String message);

}
