package com.hexaware.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
@Component
public class MessageSender {
	   private  MessageService messageService1 = null;
	    private  MessageService messageService2 = null;

	    /*Constructor Based Dependency Injection
	     * @Autowired
	    public MessageSender(@Qualifier("smsService") MessageService messageService1,
	                         @Qualifier("emailService") MessageService messageService2) {
	        this.messageService1 = messageService1;
	        this.messageService2 = messageService2;
	    }*/	

	    public void sendMessage(String m, String type) {
	        if ("email".equals(type)) {
	            this.messageService2.sendMessage(m);
	        } else {
	            this.messageService1.sendMessage(m);
	        }
	    }
//Setter Based Dependency Injection
		public MessageService getMessageService1() {
			return messageService1;
		}
        @Autowired
		public void setMessageService1(@Qualifier("smsService")MessageService messageService1) {
			this.messageService1 = messageService1;
		}
         
		public MessageService getMessageService2() {
			return messageService2;
		}
        @Autowired
		public void setMessageService2(@Qualifier("emailService")MessageService messageService2) {
			this.messageService2 = messageService2;
		}

	

	

}
